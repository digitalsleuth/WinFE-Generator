libbfio is licensed under LGPL; here is a link to the source code: 
https://googledrive.com/host/0B3fBvzttpiiSTERGV3V4bnZ3dlk/libbfio-alpha-20131003.tar.gz 
