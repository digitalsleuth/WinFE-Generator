libvshadow is licensed under LGPL; here is a link to the source code: 
https://googledrive.com/host/0B3fBvzttpiiSZDZXRFVMdnZCeHc/libvshadow-alpha-20131003.tar.gz 
